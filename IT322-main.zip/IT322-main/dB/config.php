<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "IT322";

$con = new mysqli($servername, $username, $password, $database);

if ($con -> connect_error){
    
}
?>